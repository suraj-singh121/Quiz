## **Quizzo** 🧐✅
The Quizzo app is a MCQ type quiz game in which the user selects the correct flag for the corresponding country. It is made using Kotlin.
It consists of these files

- Constants.kt
- MainActivity.kt
- Question.kt
- QuizQuestionsActivity.kt
- ResultActivity.kt

## **Image**
![Q](https://user-images.githubusercontent.com/89503697/180143728-62172246-d286-4b81-aad0-7e13c718ef51.png)
